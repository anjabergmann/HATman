/**
 * This package stores helpful classes for both client and server.
 */
package marauroa.common;

