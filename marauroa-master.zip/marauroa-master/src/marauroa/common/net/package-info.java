/**
 * This package stores all the serializers to build Messages from a stream of bytes and 
 * from a Message create a stream of bytes representing it.
 * <p>
 * Also it contains a subclass with all the Message classes.
 */
package marauroa.common.net;

