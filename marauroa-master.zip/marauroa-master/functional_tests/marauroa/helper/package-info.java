/* as Eclipse does not fork jvm perTest, to make the tests also run in batches in eclipse 
 * we need to reset the static references.
 * This package provides the classes needed.
 * 
 */
package marauroa.helper;

