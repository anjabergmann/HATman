/**
 * database specific low level code.
 */
package marauroa.server.db.adapter;