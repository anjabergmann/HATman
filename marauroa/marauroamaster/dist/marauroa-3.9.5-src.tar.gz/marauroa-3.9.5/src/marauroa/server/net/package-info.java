/**
 * Network communication.
 *
 * <img src="doc-files/net.png">
 */
package marauroa.server.net;
