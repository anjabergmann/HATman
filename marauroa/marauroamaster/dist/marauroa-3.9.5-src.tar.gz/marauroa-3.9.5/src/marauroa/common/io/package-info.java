/**
 * Contains classes that allows transparent access to files. Subclasses implement Persistence
 * for normal and webstart environment. 
 */
package marauroa.common.io;

