/**
 * This package contains the client framework that you need to extend to
 * implement a real client.
 */
package marauroa.client;

