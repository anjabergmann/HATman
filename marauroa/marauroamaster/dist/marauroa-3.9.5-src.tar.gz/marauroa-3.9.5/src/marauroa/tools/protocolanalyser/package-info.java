/**
 * This packages analyses network dumps.
 */
package marauroa.tools.protocolanalyser;