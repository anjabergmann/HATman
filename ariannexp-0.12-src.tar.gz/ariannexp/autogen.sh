aclocal-1.7 &&
autoheader &&
libtoolize --force &&
automake-1.7 --add-missing &&
autoconf
